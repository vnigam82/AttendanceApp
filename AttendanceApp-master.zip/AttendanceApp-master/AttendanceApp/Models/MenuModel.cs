﻿using System;
namespace AttendanceApp.Models
{
    public class MenuModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string ImageName { get; set; }
        public string GridColor { get; set; }
    }
}
