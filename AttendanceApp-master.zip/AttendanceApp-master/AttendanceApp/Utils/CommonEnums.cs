﻿using System;
namespace AttendanceApp.Utils
{
    public class CommonEnums
    {
        public CommonEnums()
        {
        }
    }
    
}
