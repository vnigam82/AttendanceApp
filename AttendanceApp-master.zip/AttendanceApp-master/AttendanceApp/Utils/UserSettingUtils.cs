﻿using System;
namespace AttendanceApp.Utils
{
    public static class UserSettingUtils
    {
        public static string UserName { get; set; }
        public static string Password { get; set; }
        public static string UserLoginGUID { get; set; }
    }
}
