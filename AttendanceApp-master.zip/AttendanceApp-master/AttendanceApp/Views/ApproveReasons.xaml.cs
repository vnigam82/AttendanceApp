﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace AttendanceApp.Views
{
    public partial class ApproveReasons : ContentPage
    {
        public ApproveReasons()
        {
            InitializeComponent();
        }
    }
}
