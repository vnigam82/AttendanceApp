﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace AttendanceApp.Views
{
    public partial class LeaveRequest : ContentPage
    {
        public LeaveRequest()
        {
            InitializeComponent();
        }
    }
}
