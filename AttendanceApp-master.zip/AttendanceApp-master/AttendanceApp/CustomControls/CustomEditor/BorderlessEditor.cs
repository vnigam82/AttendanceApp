﻿using System;
using Xamarin.Forms;

namespace AttendanceApp.CustomControls
{
    public class BorderlessEditor : Editor
    {
        
    }
}
