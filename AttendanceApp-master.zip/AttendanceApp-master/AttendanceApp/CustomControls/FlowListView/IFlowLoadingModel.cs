﻿using System;

namespace AttendanceApp
{
    [Preserve(AllMembers = true)]
    public interface IFlowLoadingModel
    {
    }

    [Preserve(AllMembers = true)]
    internal class FlowLoadingModel : IFlowLoadingModel
    {
    }
}
