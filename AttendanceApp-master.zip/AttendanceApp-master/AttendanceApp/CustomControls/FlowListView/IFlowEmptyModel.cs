﻿using System;
namespace AttendanceApp
{
    [Preserve(AllMembers = true)]
    public interface IFlowEmptyModel
    {
    }

    [Preserve(AllMembers = true)]
    internal class FlowEmptyModel : IFlowEmptyModel
    {
    }
}