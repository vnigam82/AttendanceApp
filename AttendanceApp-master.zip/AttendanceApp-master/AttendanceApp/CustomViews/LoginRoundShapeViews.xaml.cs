﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace AttendanceApp.CustomViews
{
    public partial class LoginRoundShapeViews : ContentView
    {
        public LoginRoundShapeViews()
        {
            InitializeComponent();
        }
    }
}
